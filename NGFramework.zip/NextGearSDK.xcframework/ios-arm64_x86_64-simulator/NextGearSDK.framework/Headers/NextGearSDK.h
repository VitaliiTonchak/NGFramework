#import <Foundation/Foundation.h>

//! Project version number for NextGearSDK.
FOUNDATION_EXPORT double NextGearSDKVersionNumber;

//! Project version string for NextGearSDK.
FOUNDATION_EXPORT const unsigned char NextGearSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NextGearSDK/PublicHeader.h>


