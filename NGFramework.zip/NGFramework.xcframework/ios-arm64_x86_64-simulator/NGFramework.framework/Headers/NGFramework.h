//
//  NGFramework.h
//  NGFramework
//
//  Created by vtonchak on 25/5/23.
//

#import <Foundation/Foundation.h>

//! Project version number for NGFramework.
FOUNDATION_EXPORT double NGFrameworkVersionNumber;

//! Project version string for NGFramework.
FOUNDATION_EXPORT const unsigned char NGFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <NGFramework/PublicHeader.h>


